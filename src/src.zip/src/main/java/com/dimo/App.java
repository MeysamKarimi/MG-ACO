package com.dimo;


import com.dimo.aco.ACO;
import com.dimo.aco.DiscoveredPath;
import com.dimo.model.MetaModel;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.EcoreResourceFactoryImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.ocl.OCL;
import org.eclipse.ocl.OCLInput;
import org.eclipse.ocl.ecore.Constraint;
import org.eclipse.ocl.ecore.EcoreEnvironmentFactory;

import java.io.FileInputStream;
import java.io.InputStream;
import java.lang.management.ManagementFactory;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class App {

    public static void main(String[] args){
        long startTime = System.currentTimeMillis();
        MetaModel metaModel = new MetaModel(loadMetamodel(), loadOclRules());
        DiscoveredPath discoveredPath = new DiscoveredPath(metaModel, BigDecimal.ONE, 1, 0, BigDecimal.ONE);
        ACO aco = new ACO(metaModel, discoveredPath, 10, 1, 10, 1, BigDecimal.ONE, new BigDecimal("0.01"));
        aco.run();
        long endTime = System.currentTimeMillis();
        System.out.println("Execution Time(MS): " + (endTime - startTime));
        System.out.println("Heap: " + ManagementFactory.getMemoryMXBean().getHeapMemoryUsage());
        System.out.println("NonHeap: " + ManagementFactory.getMemoryMXBean().getNonHeapMemoryUsage());
    }


    private static Resource loadMetamodel() { // loads the input metamodel
        try {
            ResourceSet resourceSet = new ResourceSetImpl();
            resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap()
                    .put("ecore", new EcoreResourceFactoryImpl());
            resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap()
                    .put("xmi", new XMIResourceFactoryImpl());
            Resource myMetaModel = resourceSet
                    .getResource(URI.createFileURI(App.class.getClassLoader().getResource("Families.ecore").getPath()),true);
            registerPackages(myMetaModel);
            System.out.println("Problem.metaModel is loaded!");
            return myMetaModel;
        } catch (Exception ex) {
            System.out.println("Unable to load the Metamodel");
            throw ex;
        }
    }
    private static Map<String, Constraint> loadOclRules() {
        Map<String, Constraint> oclConstraints;
        OCL ocl = OCL.newInstance(EcoreEnvironmentFactory.INSTANCE);
        InputStream in = null;
        try {
            in = new FileInputStream(App.class.getClassLoader().getResource("Families.ocl").getPath());
            Map<String, Constraint> constraintMap = new HashMap<>();
            // parse the contents as an OCL document
            OCLInput document = new OCLInput(in);
            List<Constraint> constraints = ocl.parse(document);
            for (Constraint next : constraints) {
                constraintMap.put(next.getName(), next);
            }
            in.close();
            oclConstraints = constraintMap;
        } catch (Exception ex) {
            System.out.printf("Error in parsing OCL file, The OCL check is ignored! The exception: ", ex.getStackTrace());
            oclConstraints = Map.of();
        }
        return oclConstraints;
    }
    private static void registerPackages(Resource resource){
        EObject eObject = resource.getContents().get(0);
        if(eObject instanceof EPackage)
        {
            EPackage p = (EPackage) eObject;
            EPackage.Registry.INSTANCE.put(p.getNsURI(), p);
        }
    }
}
