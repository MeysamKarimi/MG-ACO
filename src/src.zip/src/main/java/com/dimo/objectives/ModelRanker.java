package com.dimo.objectives;

import com.dimo.model.MetaModel;
import com.dimo.model.Model;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ModelRanker {


    private ExternalDivObjective externalDivObjective;
    private InternalDivObjective internalDivObjective;
    private MetaModel metaModel;

    public ModelRanker(MetaModel metaModel) {
        this.metaModel = metaModel;
        internalDivObjective = new InternalDivObjective();
        externalDivObjective = new ExternalDivObjective();
    }

    // Todo change this impl
    public List<Model> rankModels(List<Model> models) {
        List<ModelObjective> objectives = models
                .stream()
                .map(ModelObjective::new)
                .collect(Collectors.toList());
        objectives.forEach(objective -> objective.setInternalDiv(internalDivObjective.score(objective.getModel(), metaModel)));

        //Todo optimize this
        objectives.forEach(objective -> objective.setExternalDiv(
                objectives
                        .stream()
                        .map(m -> externalDivObjective.compare(objective.getModel().getModelResource(), m.getModel().getModelResource()))
                        .reduce(Integer::sum)
                        .orElse(0)
        ));
        objectives.sort(Comparator.comparing(ModelObjective::getExternalDiv).reversed());
        objectives.sort(Comparator.comparing(ModelObjective::getInternalDiv).reversed());
        System.out.println(objectives.get(0).getInternalDiv());
        System.out.println(objectives.get(0).getExternalDiv());
        return objectives.stream().map(ModelObjective::getModel).collect(Collectors.toList());
    }
}
